import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";

export const Route = createFileRoute("/privacidad")({
  head: () => ({
    meta: [
      { title: "Privacidad — GM Advance" },
      { name: "description", content: "Política de privacidad de GM Advance." },
    ],
  }),
  component: () => (
    <SiteLayout>
      <article className="mx-auto max-w-3xl px-4 py-24 sm:px-6 lg:px-8">
        <h1 className="font-display text-4xl font-bold text-silver">Política de privacidad</h1>
        <p className="mt-6 text-silver/70">
          En GM Advance respetamos tu privacidad. Solo almacenamos los datos estrictamente necesarios para
          gestionar tu solicitud y nunca los compartimos con terceros sin tu consentimiento.
        </p>
      </article>
    </SiteLayout>
  ),
});
