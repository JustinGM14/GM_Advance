import { createFileRoute, Link } from "@tanstack/react-router";
import { Code2, Smartphone, Cloud, Check, ArrowRight } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";
import { BackgroundGrid } from "@/components/BackgroundGrid";
import { Reveal } from "@/components/Reveal";
import { useLang } from "@/i18n/LanguageProvider";

export const Route = createFileRoute("/servicios")({
  head: () => ({
    meta: [
      { title: "Servicios — GM Advance" },
      { name: "description", content: "Desarrollo web, apps móviles y hosting cloud a medida." },
      { property: "og:title", content: "Servicios — GM Advance" },
      { property: "og:description", content: "Web · Apps · Hosting de alto rendimiento." },
    ],
  }),
  component: Services,
});

function Services() {
  const { t, lang } = useLang();

  const featuresEs = {
    web: ["Diseño UI/UX", "React / Next.js", "SEO técnico", "E-commerce", "CMS headless"],
    apps: ["iOS nativo (Swift)", "Android (Kotlin)", "React Native", "Push & analítica", "Publicación en stores"],
    hosting: ["CDN global", "SSL automático", "Backups diarios", "Monitorización 24/7", "Auto-scaling"],
  };
  const featuresEn = {
    web: ["UI/UX design", "React / Next.js", "Technical SEO", "E-commerce", "Headless CMS"],
    apps: ["Native iOS (Swift)", "Android (Kotlin)", "React Native", "Push & analytics", "Store publishing"],
    hosting: ["Global CDN", "Automatic SSL", "Daily backups", "24/7 monitoring", "Auto-scaling"],
  };

  const isEn = lang === "en";
  const F = isEn ? featuresEn : featuresEs;

  const services = [
    { key: "web", Icon: Code2, ...t.services.web, features: F.web, price: isEn ? "from €2,500" : "desde 2.500 €" },
    { key: "apps", Icon: Smartphone, ...t.services.apps, features: F.apps, price: isEn ? "from €6,000" : "desde 6.000 €" },
    { key: "hosting", Icon: Cloud, ...t.services.hosting, features: F.hosting, price: isEn ? "from €29/mo" : "desde 29 €/mes" },
  ];

  return (
    <SiteLayout>
      <section className="relative overflow-hidden">
        <BackgroundGrid />
        <div className="mx-auto max-w-5xl px-4 py-24 sm:px-6 lg:px-8">
          <Reveal>
            <p className="font-mono text-xs uppercase tracking-widest text-silver/50">// services</p>
            <h1 className="mt-3 font-display text-5xl font-bold text-silver sm:text-6xl">{t.nav.services}</h1>
            <p className="mt-6 max-w-2xl text-lg text-silver/70">
              {isEn
                ? "End-to-end engineering: from product strategy to production deployment."
                : "Ingeniería de extremo a extremo: de la estrategia de producto al despliegue en producción."}
            </p>
          </Reveal>
        </div>
      </section>

      <section className="border-t border-silver/10 py-20">
        <div className="mx-auto max-w-6xl space-y-8 px-4 sm:px-6 lg:px-8">
          {services.map((s, i) => (
            <Reveal key={s.key} delay={i * 0.05}>
              <div className="grid gap-8 rounded-xl border border-silver/15 bg-navy/25 p-8 lg:grid-cols-[1fr_2fr]">
                <div>
                  <s.Icon className="h-10 w-10 text-silver" strokeWidth={1.5} />
                  <h2 className="mt-4 font-display text-3xl font-bold text-silver">{s.title}</h2>
                  <p className="mt-3 text-silver/70">{s.desc}</p>
                  <p className="mt-6 font-mono text-sm text-silver/50">{s.price}</p>
                </div>
                <div>
                  <ul className="grid gap-3 sm:grid-cols-2">
                    {s.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-silver/80">
                        <Check size={16} className="text-silver" /> {f}
                      </li>
                    ))}
                  </ul>
                  <Link
                    to="/contacto"
                    className="mt-8 inline-flex items-center gap-2 rounded-lg border border-silver/30 px-5 py-2.5 font-mono text-sm text-silver hover:bg-navy/40"
                  >
                    {t.cta.getQuote} <ArrowRight size={14} />
                  </Link>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
