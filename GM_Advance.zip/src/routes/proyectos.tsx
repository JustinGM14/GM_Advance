import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ExternalLink } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";
import { BackgroundGrid } from "@/components/BackgroundGrid";
import { Reveal } from "@/components/Reveal";
import { useLang } from "@/i18n/LanguageProvider";

export const Route = createFileRoute("/proyectos")({
  head: () => ({
    meta: [
      { title: "Proyectos — GM Advance" },
      { name: "description", content: "Selección de proyectos web, apps y cloud de GM Advance." },
      { property: "og:title", content: "Proyectos — GM Advance" },
      { property: "og:description", content: "Trabajos recientes en web, mobile e infraestructura." },
    ],
  }),
  component: Projects,
});

const PROJECTS = [
  { name: "Nimbus Commerce", cat: "Web", tags: ["Next.js", "Stripe"], desc: "E-commerce headless con +40% de conversión." },
  { name: "Voltra App", cat: "Apps", tags: ["React Native", "Firebase"], desc: "App de movilidad eléctrica con 50k descargas." },
  { name: "Atlas Cloud", cat: "Hosting", tags: ["AWS", "K8s"], desc: "Infraestructura multi-región con 99.99% uptime." },
  { name: "Helia Studio", cat: "Web", tags: ["React", "GSAP"], desc: "Portfolio editorial con animaciones avanzadas." },
  { name: "Forge ERP", cat: "Web", tags: ["TanStack", "Postgres"], desc: "ERP a medida para industria manufacturera." },
  { name: "Pulse Health", cat: "Apps", tags: ["Swift", "HealthKit"], desc: "App iOS para monitorización biomédica." },
];

function Projects() {
  const { t } = useLang();
  const [filter, setFilter] = useState<string>("All");
  const cats = [t.projects.all, "Web", "Apps", "Hosting"];
  const filtered = filter === t.projects.all || filter === "All"
    ? PROJECTS
    : PROJECTS.filter((p) => p.cat === filter);

  return (
    <SiteLayout>
      <section className="relative overflow-hidden">
        <BackgroundGrid />
        <div className="mx-auto max-w-6xl px-4 py-24 sm:px-6 lg:px-8">
          <Reveal>
            <p className="font-mono text-xs uppercase tracking-widest text-silver/50">// work</p>
            <h1 className="mt-3 font-display text-5xl font-bold text-silver sm:text-6xl">{t.projects.title}</h1>
            <p className="mt-6 max-w-2xl text-lg text-silver/70">{t.projects.sub}</p>
          </Reveal>

          <div className="mt-10 flex flex-wrap gap-2">
            {cats.map((c) => (
              <button
                key={c}
                onClick={() => setFilter(c)}
                className={`rounded-full border px-4 py-1.5 font-mono text-xs uppercase tracking-wider transition-colors ${
                  (filter === c) || (c === t.projects.all && filter === "All")
                    ? "border-silver bg-silver text-background"
                    : "border-silver/20 text-silver/70 hover:text-silver"
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filtered.map((p, i) => (
              <Reveal key={p.name} delay={i * 0.05}>
                <article className="group relative h-full overflow-hidden rounded-xl border border-silver/15 bg-navy/30 p-6 transition-all hover:-translate-y-1 hover:border-silver/40">
                  <div className="flex items-start justify-between">
                    <span className="font-mono text-xs uppercase text-silver/50">{p.cat}</span>
                    <ExternalLink size={14} className="text-silver/40 transition-colors group-hover:text-silver" />
                  </div>
                  <h3 className="mt-4 font-display text-xl font-semibold text-silver">{p.name}</h3>
                  <p className="mt-2 text-sm text-silver/65">{p.desc}</p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {p.tags.map((tag) => (
                      <span key={tag} className="rounded border border-silver/15 px-2 py-0.5 font-mono text-[11px] text-silver/60">
                        {tag}
                      </span>
                    ))}
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
