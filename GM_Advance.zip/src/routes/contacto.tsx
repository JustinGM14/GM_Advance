import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";
import { BackgroundGrid } from "@/components/BackgroundGrid";
import { Reveal } from "@/components/Reveal";
import { useLang } from "@/i18n/LanguageProvider";

export const Route = createFileRoute("/contacto")({
  head: () => ({
    meta: [
      { title: "Contacto — GM Advance" },
      { name: "description", content: "Habla con el equipo de GM Advance. Respondemos en menos de 24h." },
      { property: "og:title", content: "Contacto — GM Advance" },
      { property: "og:description", content: "Cuéntanos tu proyecto." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const { t } = useLang();
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState<"idle" | "ok" | "error">("idle");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name || !/^\S+@\S+\.\S+$/.test(form.email) || form.message.length < 5) {
      setStatus("error");
      return;
    }
    setStatus("ok");
    setForm({ name: "", email: "", message: "" });
  }

  return (
    <SiteLayout>
      <section className="relative overflow-hidden">
        <BackgroundGrid />
        <div className="mx-auto grid max-w-6xl gap-12 px-4 py-24 sm:px-6 lg:grid-cols-2 lg:px-8">
          <Reveal>
            <p className="font-mono text-xs uppercase tracking-widest text-silver/50">// contact</p>
            <h1 className="mt-3 font-display text-5xl font-bold text-silver sm:text-6xl">{t.contact.title}</h1>
            <p className="mt-6 text-lg text-silver/70">{t.contact.sub}</p>
            <ul className="mt-10 space-y-4 text-silver/80">
              <li className="flex items-center gap-3"><Mail size={16} /> hello@gmadvance.dev</li>
              <li className="flex items-center gap-3"><Phone size={16} /> +34 600 000 000</li>
              <li className="flex items-center gap-3"><MapPin size={16} /> Madrid, España</li>
            </ul>
            <pre className="mt-10 overflow-hidden rounded-lg border border-silver/15 bg-navy/40 p-4 font-mono text-xs text-silver/60">
{`{
  "available": true,
  "response_time": "< 24h",
  "timezone": "GMT+1"
}`}
            </pre>
          </Reveal>

          <Reveal delay={0.15}>
            <form onSubmit={submit} className="space-y-5 rounded-xl border border-silver/15 bg-navy/30 p-8">
              <Field label={t.contact.name} value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
              <Field label={t.contact.email} type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} />
              <div>
                <label className="font-mono text-xs uppercase tracking-widest text-silver/50">{t.contact.message}</label>
                <textarea
                  rows={5}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="mt-2 w-full rounded-lg border border-silver/20 bg-background/40 p-3 text-silver outline-none placeholder:text-silver/30 focus:border-silver/60"
                />
              </div>
              <button
                type="submit"
                className="inline-flex items-center gap-2 rounded-lg bg-silver px-5 py-3 font-mono text-sm font-medium text-background hover:gap-3 transition-all"
              >
                <Send size={14} /> {t.cta.sendMessage}
              </button>
              {status === "ok" && <p className="font-mono text-xs text-silver/80">✓ {t.contact.success}</p>}
              {status === "error" && <p className="font-mono text-xs text-destructive">{t.contact.error}</p>}
            </form>
          </Reveal>
        </div>
      </section>
    </SiteLayout>
  );
}

function Field({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <div>
      <label className="font-mono text-xs uppercase tracking-widest text-silver/50">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-2 w-full rounded-lg border border-silver/20 bg-background/40 p-3 text-silver outline-none focus:border-silver/60"
      />
    </div>
  );
}
