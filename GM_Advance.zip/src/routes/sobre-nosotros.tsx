import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import { BackgroundGrid } from "@/components/BackgroundGrid";
import { Reveal } from "@/components/Reveal";
import { useLang } from "@/i18n/LanguageProvider";

export const Route = createFileRoute("/sobre-nosotros")({
  head: () => ({
    meta: [
      { title: "Sobre nosotros — GM Advance" },
      { name: "description", content: "Conoce al equipo de GM Advance: ingenieros enfocados en producto digital." },
      { property: "og:title", content: "Sobre nosotros — GM Advance" },
      { property: "og:description", content: "Misión, visión, valores y trayectoria de GM Advance." },
    ],
  }),
  component: About,
});

const TIMELINE = [
  { year: "2020", t: "Fundación", d: "Nace GM Advance con la misión de construir software de élite." },
  { year: "2022", t: "+25 proyectos", d: "Crecemos a un equipo multidisciplinar full-stack." },
  { year: "2024", t: "Cloud & Hosting", d: "Lanzamos nuestra unidad de infraestructura gestionada." },
  { year: "2026", t: "Expansión", d: "Operamos con clientes en Europa y Latinoamérica." },
];

function About() {
  const { t } = useLang();
  return (
    <SiteLayout>
      <section className="relative overflow-hidden">
        <BackgroundGrid />
        <div className="mx-auto max-w-5xl px-4 py-24 sm:px-6 lg:px-8">
          <Reveal>
            <p className="font-mono text-xs uppercase tracking-widest text-silver/50">// about</p>
            <h1 className="mt-3 font-display text-5xl font-bold tracking-tight text-silver sm:text-6xl">
              {t.about.title}
            </h1>
            <p className="mt-6 max-w-2xl text-lg text-silver/70">{t.about.sub}</p>
          </Reveal>
        </div>
      </section>

      <section className="border-t border-silver/10 py-20">
        <div className="mx-auto grid max-w-5xl gap-8 px-4 sm:px-6 md:grid-cols-2 lg:px-8">
          <Reveal>
            <div className="rounded-xl border border-silver/15 bg-navy/30 p-8">
              <h3 className="font-mono text-xs uppercase tracking-widest text-silver/50">// mission</h3>
              <h2 className="mt-3 font-display text-2xl font-semibold text-silver">{t.about.missionTitle}</h2>
              <p className="mt-3 text-silver/70">{t.about.missionText}</p>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <div className="rounded-xl border border-silver/15 bg-navy/30 p-8">
              <h3 className="font-mono text-xs uppercase tracking-widest text-silver/50">// vision</h3>
              <h2 className="mt-3 font-display text-2xl font-semibold text-silver">{t.about.visionTitle}</h2>
              <p className="mt-3 text-silver/70">{t.about.visionText}</p>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="border-t border-silver/10 py-20">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <h2 className="font-display text-3xl font-bold text-silver">{t.about.valuesTitle}</h2>
          </Reveal>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {t.about.values.map((v, i) => (
              <Reveal key={v.t} delay={i * 0.08}>
                <div className="h-full rounded-xl border border-silver/15 bg-navy/20 p-6">
                  <span className="font-mono text-xs text-silver/40">0{i + 1}</span>
                  <h4 className="mt-2 font-display text-lg font-semibold text-silver">{v.t}</h4>
                  <p className="mt-2 text-sm text-silver/65">{v.d}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-silver/10 py-20">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <h2 className="font-display text-3xl font-bold text-silver">{t.about.timelineTitle}</h2>
          </Reveal>
          <ol className="mt-10 space-y-6 border-l border-silver/20 pl-6">
            {TIMELINE.map((m, i) => (
              <Reveal key={m.year} delay={i * 0.08}>
                <li className="relative">
                  <span className="absolute -left-[31px] top-2 h-2 w-2 rounded-full bg-silver" />
                  <span className="font-mono text-xs text-silver/50">{m.year}</span>
                  <h4 className="mt-1 font-display text-xl font-semibold text-silver">{m.t}</h4>
                  <p className="mt-1 text-silver/65">{m.d}</p>
                </li>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>
    </SiteLayout>
  );
}
