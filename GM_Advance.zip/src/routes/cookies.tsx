import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";

export const Route = createFileRoute("/cookies")({
  head: () => ({
    meta: [
      { title: "Cookies — GM Advance" },
      { name: "description", content: "Política de cookies de GM Advance." },
    ],
  }),
  component: () => (
    <SiteLayout>
      <article className="mx-auto max-w-3xl px-4 py-24 sm:px-6 lg:px-8">
        <h1 className="font-display text-4xl font-bold text-silver">Política de cookies</h1>
        <p className="mt-6 text-silver/70">
          Este sitio utiliza cookies estrictamente necesarias para su funcionamiento. No empleamos cookies de
          terceros para publicidad ni seguimiento.
        </p>
      </article>
    </SiteLayout>
  ),
});
