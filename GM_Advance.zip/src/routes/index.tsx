import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Code2, Smartphone, Cloud, Sparkles } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";
import { BackgroundGrid } from "@/components/BackgroundGrid";
import { CodeWindow } from "@/components/CodeWindow";
import { Reveal } from "@/components/Reveal";
import { TypewriterText } from "@/components/TypewriterText";
import { useLang } from "@/i18n/LanguageProvider";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GM Advance — Desarrollo Web, Apps y Hosting" },
      { name: "description", content: "Estudio de programación enfocado en webs, apps y hosting de alto rendimiento." },
      { property: "og:title", content: "GM Advance" },
      { property: "og:description", content: "Webs, apps y hosting hechos con código de élite." },
    ],
  }),
  component: Home,
});

const TECH = ["React", "Next.js", "TypeScript", "Node.js", "PostgreSQL", "Tailwind", "AWS", "Docker", "Kubernetes", "Swift", "Kotlin", "GraphQL", "Vite", "Cloudflare"];

function Home() {
  const { t } = useLang();

  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <BackgroundGrid />
        <div className="mx-auto grid max-w-7xl gap-12 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:py-32 lg:px-8">
          <div className="flex flex-col justify-center">
            <Reveal>
              <span className="inline-flex w-fit items-center gap-2 rounded-full border border-silver/20 bg-navy/30 px-3 py-1 font-mono text-xs uppercase tracking-widest text-silver/70">
                <Sparkles size={12} /> {t.home.badge}
              </span>
            </Reveal>
            <Reveal delay={0.1}>
              <h1 className="mt-6 font-display text-5xl font-bold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
                <TypewriterText
                  text={`{ ${t.home.heroTitle} ${t.home.heroTitleAccent} }`}
                  speed={120}
                  className="text-gradient-silver"
                />
              </h1>
            </Reveal>
            <Reveal delay={0.2}>
              <p className="mt-6 max-w-xl text-lg text-silver/70">{t.home.heroSub}</p>
            </Reveal>
            <Reveal delay={0.3}>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link
                  to="/contacto"
                  className="group inline-flex items-center gap-2 rounded-lg bg-silver px-5 py-3 font-mono text-sm font-medium text-background transition-all hover:gap-3"
                >
                  {t.cta.start} <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
                </Link>
                <Link
                  to="/proyectos"
                  className="inline-flex items-center gap-2 rounded-lg border border-silver/30 px-5 py-3 font-mono text-sm text-silver hover:bg-navy/40"
                >
                  {t.cta.viewWork}
                </Link>
              </div>
            </Reveal>
            <Reveal delay={0.4}>
              <p className="mt-10 font-mono text-xs text-silver/40">
                <span className="cursor-blink">$ gm-advance --init</span>
              </p>
            </Reveal>
          </div>
          <Reveal delay={0.2} className="flex items-center">
            <CodeWindow />
          </Reveal>
        </div>
      </section>

      {/* SERVICES */}
      <section className="relative border-t border-silver/10 py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionHeading kicker="// services" title={t.home.servicesTitle} sub={t.home.servicesSub} />
          </Reveal>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {[
              { Icon: Code2, ...t.services.web },
              { Icon: Smartphone, ...t.services.apps },
              { Icon: Cloud, ...t.services.hosting },
            ].map((s, i) => (
              <Reveal key={s.title} delay={i * 0.1}>
                <div className="group relative h-full overflow-hidden rounded-xl border border-silver/15 bg-navy/30 p-7 transition-all hover:border-silver/40 hover:-translate-y-1">
                  <div
                    className="pointer-events-none absolute -inset-px opacity-0 transition-opacity group-hover:opacity-100"
                    style={{ background: "radial-gradient(400px circle at 50% 0%, rgba(196,196,196,0.08), transparent 60%)" }}
                  />
                  <s.Icon className="h-7 w-7 text-silver" strokeWidth={1.5} />
                  <h3 className="mt-5 font-display text-xl font-semibold text-silver">{s.title}</h3>
                  <p className="mt-3 text-sm text-silver/65">{s.desc}</p>
                  <span className="mt-6 inline-flex items-center gap-1 font-mono text-xs text-silver/50">
                    {"</>"} module
                  </span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* STACK MARQUEE */}
      <section className="relative border-t border-silver/10 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <p className="text-center font-mono text-xs uppercase tracking-widest text-silver/50">
              {t.home.stackTitle}
            </p>
          </Reveal>
        </div>
        <div className="mt-8 overflow-hidden">
          <div className="flex w-max animate-marquee gap-12 px-6">
            {[...TECH, ...TECH].map((t, i) => (
              <span key={i} className="font-mono text-2xl text-silver/40 hover:text-silver">
                {t}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section className="relative border-t border-silver/10 py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Reveal>
            <SectionHeading kicker="// process" title={t.home.processTitle} sub={t.home.processSub} />
          </Reveal>
          <div className="mt-14 grid gap-6 md:grid-cols-4">
            {t.process.map((p, i) => (
              <Reveal key={p.t} delay={i * 0.1}>
                <div className="relative rounded-xl border border-silver/15 bg-navy/20 p-6">
                  <span className="font-mono text-xs text-silver/40">0{i + 1}</span>
                  <h4 className="mt-3 font-display text-lg font-semibold text-silver">{p.t}</h4>
                  <p className="mt-2 text-sm text-silver/65">{p.d}</p>
                  {i < t.process.length - 1 && (
                    <div className="absolute -right-3 top-1/2 hidden h-px w-6 bg-silver/20 md:block" />
                  )}
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative border-t border-silver/10 py-24">
        <BackgroundGrid />
        <div className="relative mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <Reveal>
            <h2 className="font-display text-4xl font-bold tracking-tight text-silver sm:text-5xl">
              {t.home.ctaTitle}
            </h2>
            <p className="mt-4 text-silver/70">{t.home.ctaSub}</p>
            <Link
              to="/contacto"
              className="mt-8 inline-flex items-center gap-2 rounded-lg bg-silver px-6 py-3 font-mono text-sm font-medium text-background hover:gap-3 transition-all"
            >
              {t.cta.start} <ArrowRight size={16} />
            </Link>
          </Reveal>
        </div>
      </section>
    </SiteLayout>
  );
}

function SectionHeading({ kicker, title, sub }: { kicker: string; title: string; sub?: string }) {
  return (
    <div className="max-w-2xl">
      <p className="font-mono text-xs uppercase tracking-widest text-silver/50">{kicker}</p>
      <h2 className="mt-3 font-display text-4xl font-bold tracking-tight text-silver sm:text-5xl">
        {title}
      </h2>
      {sub && <p className="mt-3 text-silver/65">{sub}</p>}
    </div>
  );
}
