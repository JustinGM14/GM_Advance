import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";

export const Route = createFileRoute("/terminos")({
  head: () => ({
    meta: [
      { title: "Términos — GM Advance" },
      { name: "description", content: "Términos y condiciones de GM Advance." },
    ],
  }),
  component: () => (
    <SiteLayout>
      <article className="mx-auto max-w-3xl px-4 py-24 sm:px-6 lg:px-8">
        <h1 className="font-display text-4xl font-bold text-silver">Términos y condiciones</h1>
        <p className="mt-6 text-silver/70">
          El uso de este sitio y de los servicios prestados por GM Advance se rige por los presentes términos.
          Al contratar nuestros servicios aceptas estas condiciones.
        </p>
      </article>
    </SiteLayout>
  ),
});
