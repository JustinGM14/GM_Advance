import { motion } from "framer-motion";
import { useLang } from "@/i18n/LanguageProvider";

export function LanguageToggle() {
  const { lang, setLang } = useLang();
  const options: Array<"es" | "en"> = ["es", "en"];

  return (
    <div className="relative inline-flex items-center rounded-full border border-silver/20 bg-navy/40 p-1 font-mono text-xs backdrop-blur">
      {options.map((opt) => {
        const active = lang === opt;
        return (
          <button
            key={opt}
            onClick={() => setLang(opt)}
            className="relative z-10 px-3 py-1 uppercase tracking-wider transition-colors"
            aria-pressed={active}
          >
            {active && (
              <motion.span
                layoutId="lang-pill"
                className="absolute inset-0 rounded-full bg-silver"
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
              />
            )}
            <span className={`relative ${active ? "text-background" : "text-silver/70 hover:text-silver"}`}>
              {opt}
            </span>
          </button>
        );
      })}
    </div>
  );
}
