import { useEffect, useState } from "react";

export function TypewriterText({
  text,
  speed = 50,
  className = "",
}: {
  text: string;
  speed?: number;
  className?: string;
}) {
  const [display, setDisplay] = useState("");

  useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      setDisplay(text.slice(0, i + 1));
      i++;
      if (i >= text.length) {
        clearInterval(timer);
      }
    }, speed);
    return () => clearInterval(timer);
  }, [text, speed]);

  return (
    <span>
      <span className={className}>{display}</span>
      <span
        className="ml-0.5 inline-block translate-y-[0.1em] animate-[blink_1s_steps(1)_infinite] font-mono text-silver"
        style={{ lineHeight: 1 }}
      >
        _
      </span>
    </span>
  );
}
