import { useEffect, useState } from "react";

const lines = [
  { t: 'const gm = new Advance({', c: "text-silver" },
  { t: '  stack: ["React", "Node", "Cloud"],', c: "text-silver/80" },
  { t: '  focus: "performance",', c: "text-silver/80" },
  { t: '  delivery: "on-time",', c: "text-silver/80" },
  { t: "});", c: "text-silver" },
  { t: "", c: "" },
  { t: "// shipping production code since 2020", c: "text-silver/40" },
  { t: "gm.build(yourIdea).deploy();", c: "text-silver" },
];

export function CodeWindow() {
  const [shown, setShown] = useState<string[]>([]);
  const [current, setCurrent] = useState("");
  const [idx, setIdx] = useState(0);
  const [charIdx, setCharIdx] = useState(0);

  useEffect(() => {
    if (idx >= lines.length) return;
    const target = lines[idx].t;
    if (charIdx <= target.length) {
      const timeout = setTimeout(() => {
        setCurrent(target.slice(0, charIdx));
        setCharIdx((c) => c + 1);
      }, target.length === 0 ? 80 : 22);
      return () => clearTimeout(timeout);
    } else {
      setShown((s) => [...s, target]);
      setCurrent("");
      setCharIdx(0);
      setIdx((i) => i + 1);
    }
  }, [charIdx, idx]);

  return (
    <div className="relative w-full overflow-hidden rounded-xl border border-silver/15 bg-navy/60 shadow-[0_30px_80px_-20px_rgba(5,10,48,0.8)] backdrop-blur">
      <div className="flex items-center gap-2 border-b border-silver/10 bg-background/40 px-4 py-3">
        <span className="h-3 w-3 rounded-full bg-silver/30" />
        <span className="h-3 w-3 rounded-full bg-silver/30" />
        <span className="h-3 w-3 rounded-full bg-silver/30" />
        <span className="ml-3 font-mono text-xs text-silver/50">~/gm-advance/index.ts</span>
      </div>
      <pre className="overflow-x-auto p-5 font-mono text-sm leading-7 sm:text-[15px]">
        {shown.map((l, i) => (
          <div key={i} className={lines[i]?.c || "text-silver"}>
            <span className="mr-4 select-none text-silver/30">{String(i + 1).padStart(2, "0")}</span>
            {l || "\u00A0"}
          </div>
        ))}
        {idx < lines.length && (
          <div className={lines[idx].c}>
            <span className="mr-4 select-none text-silver/30">{String(idx + 1).padStart(2, "0")}</span>
            {current}
            <span className="ml-0.5 inline-block h-4 w-2 translate-y-0.5 animate-pulse bg-silver" />
          </div>
        )}
      </pre>
    </div>
  );
}
