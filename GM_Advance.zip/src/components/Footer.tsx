import { Link } from "@tanstack/react-router";
import { Github, Linkedin, Twitter, Instagram, Mail, Phone, MapPin } from "lucide-react";
import { Logo } from "./Logo";
import { LanguageToggle } from "./LanguageToggle";
import { useLang } from "@/i18n/LanguageProvider";

export function Footer() {
  const { t } = useLang();

  return (
    <footer className="relative border-t border-silver/10 bg-background">
      <div className="absolute inset-0 bg-grid bg-grid-mask opacity-30 pointer-events-none" />
      <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-4">
            <Logo className="h-12 w-auto" />
            <p className="max-w-xs text-sm text-silver/60">{t.footer.tagline}</p>
            <div className="flex gap-3">
              {[
                { Icon: Github, href: "#" },
                { Icon: Linkedin, href: "#" },
                { Icon: Twitter, href: "#" },
                { Icon: Instagram, href: "#" },
              ].map(({ Icon, href }, i) => (
                <a
                  key={i}
                  href={href}
                  className="flex h-9 w-9 items-center justify-center rounded border border-silver/20 text-silver/70 transition-all hover:-translate-y-0.5 hover:border-silver hover:text-silver"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="mb-4 font-mono text-xs uppercase tracking-widest text-silver/50">
              {t.footer.company}
            </h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/" className="text-silver/70 hover:text-silver">{t.nav.home}</Link></li>
              <li><Link to="/sobre-nosotros" className="text-silver/70 hover:text-silver">{t.nav.about}</Link></li>
              <li><Link to="/proyectos" className="text-silver/70 hover:text-silver">{t.nav.projects}</Link></li>
              <li><span className="text-silver/40">{t.footer.blog}</span></li>
              <li><span className="text-silver/40">{t.footer.careers}</span></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 font-mono text-xs uppercase tracking-widest text-silver/50">
              {t.footer.services}
            </h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/servicios" className="text-silver/70 hover:text-silver">{t.services.web.title}</Link></li>
              <li><Link to="/servicios" className="text-silver/70 hover:text-silver">{t.services.apps.title}</Link></li>
              <li><Link to="/servicios" className="text-silver/70 hover:text-silver">{t.services.hosting.title}</Link></li>
              <li><span className="text-silver/40">{t.footer.maintenance}</span></li>
              <li><span className="text-silver/40">{t.footer.consulting}</span></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 font-mono text-xs uppercase tracking-widest text-silver/50">
              {t.footer.contact}
            </h4>
            <ul className="space-y-3 text-sm text-silver/70">
              <li className="flex items-center gap-2"><Mail size={14} /> hello@gmadvance.dev</li>
              <li className="flex items-center gap-2"><Phone size={14} /> +34 600 000 000</li>
              <li className="flex items-center gap-2"><MapPin size={14} /> Madrid, España</li>
            </ul>
            <div className="mt-5 space-y-2 text-sm">
              <Link to="/privacidad" className="block text-silver/60 hover:text-silver">{t.footer.privacy}</Link>
              <Link to="/terminos" className="block text-silver/60 hover:text-silver">{t.footer.terms}</Link>
              <Link to="/cookies" className="block text-silver/60 hover:text-silver">{t.footer.cookies}</Link>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-silver/10 pt-6 sm:flex-row">
          <p className="font-mono text-xs text-silver/50">
            © {new Date().getFullYear()} GM Advance. {t.footer.rights}
          </p>
          <div className="flex items-center gap-4">
            <span className="font-mono text-xs text-silver/40">{"<"}/{">"} built with care</span>
            <LanguageToggle />
          </div>
        </div>
      </div>
    </footer>
  );
}
