import logo from "@/assets/logo.png";

export function Logo({ className = "h-10 w-auto" }: { className?: string }) {
  return (
    <img
      src={logo}
      alt="GM Advance"
      className={className}
      style={{
        filter: "drop-shadow(0 0 12px rgba(196,196,196,0.15))",
        mixBlendMode: "screen",
      }}
    />
  );
}
