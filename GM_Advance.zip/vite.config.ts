import { defineConfig } from "@tanstack/start/config";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  vite: {
    base: "/GM_Advance/",
    plugins: [tailwindcss(), tsConfigPaths()],
  },
  routers: {
    server: {
      entry: "./src/server.ts",
    },
  },
});
